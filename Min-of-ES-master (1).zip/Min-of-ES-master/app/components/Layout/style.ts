import styled from "styled-components";

export const LayoutWrapper = styled.main`
  font-family: "Arial", sans-serif;
  min-height: 100vh;
  
  padding-bottom: 60px;
`;
