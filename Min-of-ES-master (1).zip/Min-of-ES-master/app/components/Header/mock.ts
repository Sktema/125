export const navLinks = [
  {
    id: 0,
    title: "Главная",
    path: "/",
  },
  {
    id: 1,
    title: "Заявка",
    path: "/request",
  },
  {
    id: 3,
    title: "Вступить",
    path: "/enter",
  },
  {
    id: 4,
    title: "О нас",
    path: "about",
  },
  {
    id: 5,
    title: "Контакты",
    path: "/contacts",
  },
  {
    id: 6,
    title: "Выезд",
    path: "/departure",
  },
];
