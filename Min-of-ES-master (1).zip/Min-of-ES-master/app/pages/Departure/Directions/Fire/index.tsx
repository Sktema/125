import * as React from "react";

const Fire: React.FC = () => {
  return <h1>fire event</h1>;
};

export { Fire };
