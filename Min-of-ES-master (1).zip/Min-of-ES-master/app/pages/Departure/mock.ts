export const directions = [
  {
    id: 1,
    path: "direction?to=wanted",
    title: "На поиски",
    value: 0,
  },
  {
    id: 2,
    path: "direction?to=fire",
    title: "На пожары",
    value: 0,
  },
  {
    id: 3,
    path: "direction?to=humanitarian-aid",
    title: "Сбор гумманитарной помощи",
    value: 0,
  },
  {
    id: 4,
    path: "direction?to=emergency",
    title: "ЧС",
    value: 0,
  },
  {
    id: 5,
    path: "direction?to=zoo",
    title: "Зоо",
    value: 0,
  },
  {
    id: 6,
    path: "direction?to=eco",
    title: "Экология",
    value: 0,
  },
];
