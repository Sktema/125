export { getData } from "./getData";
export { deleteData } from "./deleteData";
export { postData } from "./postData";
